import java.util.Scanner;

import ui.UI;;

public class App {
    public static void main(String[] args) {
        try {
            UI ui = new UI();
            ui.startUi();
        } catch (Exception e) {
            System.out.println("Ups! Something went wrong.");
            System.out.println(e.getMessage());
        }
    }
}
