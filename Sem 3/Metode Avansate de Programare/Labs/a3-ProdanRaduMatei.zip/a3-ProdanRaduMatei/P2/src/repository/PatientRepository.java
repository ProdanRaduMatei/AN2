package repository;

import java.util.ArrayList;

import javax.swing.text.html.HTMLDocument.Iterator;

import domain.Patient;

public class PatientRepository extends MemoryRepository<Integer, Patient> {
}
