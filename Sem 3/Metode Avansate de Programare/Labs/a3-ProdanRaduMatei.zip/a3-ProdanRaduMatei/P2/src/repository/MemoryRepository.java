package repository;

import domain.Identifiable;

import java.util.HashMap;
import java.util.Map;

public class MemoryRepository<ID, T extends Identifiable<ID>> implements IRepository<ID, T> {
    HashMap<ID, T> elems = new HashMap<ID, T>();

    @Override
    public T add(T elem) {
        return elems.put(elem.getId(), elem);
    }

    @Override
    public T delete(ID id) {
        return elems.remove(id);
    }

    @Override
    public T update(ID id, T newElem) {
        return elems.put(id, newElem);
    }

    @Override
    public T findByID(ID id) {
        return elems.get(id);
    }

    @Override
    public Iterable<T> getAll() {
        return elems.values();
    }

    @Override
    public int size() {
        return elems.size();
    }
}
