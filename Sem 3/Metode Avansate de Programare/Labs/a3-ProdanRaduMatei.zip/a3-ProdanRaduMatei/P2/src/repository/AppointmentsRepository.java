package repository;

import domain.DoctorAppointments;

public class AppointmentsRepository extends MemoryRepository<Integer, DoctorAppointments> {
}
