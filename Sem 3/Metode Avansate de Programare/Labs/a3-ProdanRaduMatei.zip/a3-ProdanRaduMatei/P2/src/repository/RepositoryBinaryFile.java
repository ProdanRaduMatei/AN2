package repository;

public class RepositoryBinaryFile {
    
}
