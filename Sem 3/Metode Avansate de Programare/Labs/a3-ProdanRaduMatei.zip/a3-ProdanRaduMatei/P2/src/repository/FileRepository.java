package repository;

import java.io.File;
import java.util.ArrayList;

import domain.Identifiable;
import java.io.BufferedReader;
import java.io.FileReader;

public abstract class FileRepository<T extends Identifiable<ID>, ID> extends MemoryRepository<ID, T> {
    protected String filename;

    public FileRepository(String filename) {
        this.filename = filename;
        readFromFile();
    }

    protected abstract void readFromFile();
    protected abstract void writeToFile();

    @Override
    public T add(T elem) {
        super.add(elem);
        writeToFile();
        return elem;
    }

    @Override
    public T delete(ID id) {
        T elem = super.delete(id);
        writeToFile();
        return elem;
    }

    @Override
    public T update(ID id, T newElem) {
        T elem = super.update(id, newElem);
        writeToFile();
        return elem;
    }

    @Override
    public int size() {
        return super.size();
    }
}