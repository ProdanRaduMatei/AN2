package repository;

import domain.Patient;
import domain.DoctorAppointments;
import domain.Identifiable;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class AppointmentsRepositoryBinaryFile<T extends Identifiable<Integer>> extends FileRepository<T, Integer> {
    public AppointmentsRepositoryBinaryFile(String filename) {
        super(filename);
    }

    @Override
    protected void readFromFile() {
        try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            while (true) {
                T elem = (T)ois.readObject();
                super.add(elem);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void writeToFile() {
        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            for (DoctorAppointments appointments : (Iterable<DoctorAppointments>)super.getAll())
                oos.writeObject(appointments);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
