package repository;

import domain.Identifiable;

public interface IRepository<ID, T extends Identifiable<ID>> {
    T add(T elem);

    T delete(ID id);

    T update(ID id, T newElem);

    T findByID(ID id);

    Iterable<T> getAll();

    int size();
}
