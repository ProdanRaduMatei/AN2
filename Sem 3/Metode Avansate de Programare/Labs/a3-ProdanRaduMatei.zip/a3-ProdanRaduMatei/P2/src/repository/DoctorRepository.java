package repository;

import java.util.ArrayList;

import domain.Doctor;

public class DoctorRepository extends MemoryRepository<Integer, Doctor> {
}
