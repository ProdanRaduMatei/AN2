package repository;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import domain.Doctor;
import domain.Identifiable;

public class DoctorRepositoryTextFile<T extends Identifiable<ID>, ID> extends FileRepository<T, ID> {
    public DoctorRepositoryTextFile(String filename) {
        super(filename);
    }

    @Override
    protected void readFromFile() {
        try {
            BufferedReader br = new BufferedReader(new FileReader(new File(filename)));
            String line;
            while ((line = br.readLine()) != null) {
                String[] elems = line.split(";");
                if (elems.length != 5) {
                    System.err.println("Invalid line: " + line);
                    continue;
                }
                Doctor doctor = new Doctor(Integer.parseInt(elems[0].trim()), elems[1].trim(), elems[2].trim(), elems[3].trim(), elems[4].trim());
                super.add((T)doctor);
            }
            br.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void writeToFile() {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(filename));
            for (Doctor doctor : (Iterable<Doctor>)super.getAll()) {
                String line = doctor.getId() + ";" + doctor.getName() + ";" + doctor.getPhone() + ";" + doctor.getAddress() + ";" + doctor.getSpecialization();
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
