package repository;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import domain.Patient;
import domain.DoctorAppointments;
import domain.Identifiable;

public class AppointmentsRepositoryTextFile<T extends Identifiable<Integer>> extends FileRepository<T, Integer> {
    public AppointmentsRepositoryTextFile(String filename) {
        super(filename);
    }

    @Override
    protected void readFromFile() {
        try {
            BufferedReader br = new BufferedReader(new FileReader(new File(filename)));
            String line;
            while ((line = br.readLine()) != null) {
                String[] elems = line.split(";");
                if (elems.length != 6) {
                    System.err.println("Invalid line: " + line);
                    continue;
                }
                Patient patient = new Patient(Integer.parseInt(elems[0].trim()), elems[1].trim(), elems[2].trim(), elems[3].trim(), elems[4].trim(), elems[5].trim());
                super.add((T)patient);
            }
            br.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void writeToFile() {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(filename));
            for (DoctorAppointments appointments : (Iterable<DoctorAppointments>)super.getAll()) {
                String line = appointments.getId() + " " + appointments.getApointedDoctor().getId() + " " + appointments.getPatient().getId();
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
