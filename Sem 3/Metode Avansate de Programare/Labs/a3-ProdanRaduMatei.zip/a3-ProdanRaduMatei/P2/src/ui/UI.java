package ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.Buffer;
import java.security.Provider.Service;
import java.util.NoSuchElementException;
import java.util.Scanner;

import javax.print.attribute.standard.NumberOfInterveningJobs;
import javax.security.auth.login.LoginException;

import java.io.InputStreamReader;

import domain.Doctor;
import domain.DoctorAppointments;
import domain.Patient;
import services.Services;

public class UI {
    private Services services = new Services();
    final private String menu = "Dental Clinic:\n" +
                                "0. Exit\n" +
                                "1. View free doctors\n" +
                                "2. View appointments\n" +
                                "3. Add free doctor\n" +
                                "4. Remove free doctor\n" +
                                "5. Update free doctor\n" +
                                "6. Add apointment\n" +
                                "7. Remove apointment\n" +
                                "8. Update apointment\n";

    public UI() throws LoginException{
    }

    private static class PrimitiveApointment {
        public Doctor doctor;
        public Patient patient;

        PrimitiveApointment(Doctor doctor, Patient patient) {
            this.doctor = doctor;
            this.patient = patient;
        }
    }

    private Doctor askForFreeDoctor() throws IOException, RuntimeException{
        if (services.numberOfFreeDoctors() == 0) {
            throw new RuntimeException("No free doctors!");
        }
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        Doctor doctor = null;
        boolean failed;
        do {
            try {
                System.out.println("Enter doctor id:\n>>\t");
                int doctorId = Integer.parseInt(br.readLine());
                doctor = services.getFreeDoctorById(doctorId);
                failed = false;
            } catch (NoSuchElementException exception) {
                System.out.println("No doctor with that id!");
                failed = true;
            } catch (NumberFormatException exception) {
                System.out.println("Could not convert input into integer!");
                failed = true;
            }
        } while(failed);
        return doctor;
    }

    class PrimitiveDoctor {
        public String name, phone, address, specialization;

        public PrimitiveDoctor() {}
        public PrimitiveDoctor(String name, String phone, String address, String specialization) {
            this.name = name;
            this.phone = phone;
            this.address = address;
            this.specialization = specialization;
        }
    }

    private PrimitiveDoctor askUserForNewData() throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        PrimitiveDoctor primitiveDoctor = new PrimitiveDoctor();
        System.out.println("Enter doctor name:\n>>\t");
        primitiveDoctor.name = br.readLine();
        System.out.println("Enter doctor phone:\n>>\t");
        primitiveDoctor.phone = br.readLine();
        System.out.println("Enter doctor address:\n>>\t");
        primitiveDoctor.address = br.readLine();
        System.out.println("Enter doctor specialization:\n>>\t");
        primitiveDoctor.specialization = br.readLine();
        return primitiveDoctor;
    }

    private DoctorAppointments askUserForAppointment() throws IOException {
        if (services.numberOfFreeDoctors() == 0) {
            throw new RuntimeException("No free doctors!");
        }
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        DoctorAppointments appointment = null;
        boolean failed;
        do {
            try {
                System.out.println("Enter appointment id:\n>>\t");
                int appointmentId = Integer.parseInt(br.readLine());
                appointment = services.getAppointment(appointmentId);
                failed = false;
            } catch (NumberFormatException exception) {
                System.out.println("Could not convert input into integer!");
                failed = true;
            } catch (NoSuchElementException exception) {
                System.out.println("No appointment with that id!");
                failed = true;
            }
        } while(failed);
        return appointment;
    }

    private PrimitiveApointment askUserForNewAppointmentData() throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        Doctor doctor = null;
        try {
            doctor = askForFreeDoctor();
        } catch (RuntimeException exception) {
            System.out.println("No free doctors!");
            return null;
        }

        System.out.println("Enter patient name:\n>>\t");
        String patientName = br.readLine();
        System.out.println("Enter patient phone:\n>>\t");
        String patientPhone = br.readLine();
        System.out.println("Enter patient address:\n>>\t");
        String patientAddress = br.readLine();
        System.out.println("Enter patient illness:\n>>\t");
        String patientIllness = br.readLine();
        System.out.println("Enter patient treatment:\n>>\t");
        String patientTreatment = br.readLine();
        System.out.println("Enter patient id:\n>>\t");
        int patientId = Integer.parseInt(br.readLine());
        Patient patient = new Patient(patientId, patientName, patientPhone, patientAddress, patientIllness, patientTreatment);
        return new PrimitiveApointment(doctor, patient);
    }

    private String ViewAppointments() {
        StringBuilder res = new StringBuilder();
        for (DoctorAppointments appointment : services.appointments()) {
            res.append(appointment.toString());
            res.append("\n");
        }
        if (res.isEmpty())
            return "No appointments!";
        return res.toString();
    }

    private String addNewAppointment() throws IOException {
        try {
            PrimitiveApointment primitiveApointment = askUserForNewAppointmentData();
            DoctorAppointments appointment = services.makeAppointment(primitiveApointment.doctor.getId(), primitiveApointment.patient);
            return "Appointment added!\n\t" + appointment.toString() + ";";
        } catch (Exception exception) {
            return exception.getMessage();
        }
    }

    private String cancelAppointment() throws IOException {
        try {
            DoctorAppointments appointment = askUserForAppointment();
            services.cancelAppointment(appointment.getId());
            return "Canceled " + appointment.toString() + ";";
        } catch (RuntimeException exception) {
            return exception.getMessage();
        }
    }

    private String updateAppointment() throws IOException {
        try {
            DoctorAppointments appointment = askUserForAppointment();
            services.cancelAppointment(appointment.getId());
            String oldAppointment = appointment.toString();
            return addNewAppointment() + "\n Old appointment is: " + oldAppointment + ";";
        } catch (Exception exception) {
            return exception.getMessage();
        }
    }

    private String viewDoctors() throws IOException {
        StringBuilder res = new StringBuilder();
        for (Doctor doctor : services.freeDoctors()) {
            res.append(doctor.toString());
            res.append("\n");
        }
        if (res.isEmpty())
            return "No free doctors!";
        return res.toString();
    }

    private String addDoctor() throws IOException {
        PrimitiveDoctor primitiveDoctor = askUserForNewData();
        Doctor doctor = services.addNewFreeDoctor(primitiveDoctor.name, primitiveDoctor.phone, primitiveDoctor.address, primitiveDoctor.specialization);
        return "Doctor added!\n\t" + doctor.toString() + ";";
    }

    private String removeDoctor() {
        try {
            Doctor doctor = askForFreeDoctor();
            services.removeFreeDoctor(doctor.getId());
            return "Doctor removed!\n\t" + doctor.toString() + ";";
        } catch (Exception exception) {
            return exception.getMessage();
        }
    }

    private String updateDoctor() throws IOException {
        try {
            Doctor doctor = askForFreeDoctor();
            String oldDoctor = doctor.toString();
            PrimitiveDoctor updatedDoctor = askUserForNewData();
            doctor.setName(updatedDoctor.name);
            doctor.setPhone(updatedDoctor.phone);
            doctor.setAddress(updatedDoctor.address);
            doctor.setSpecialization(updatedDoctor.specialization);
            return "Doctor updated!\n\t" + oldDoctor + ";\n\t" + doctor.toString() + ";";
        } catch (Exception exception) {
            return exception.getMessage();
        }
    }

    public void startUi() throws IOException {
        boolean exit = false;
        String resMessage = "";
        while (!exit) {
            System.out.println(menu);
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            if (!resMessage.isEmpty())
                System.out.println("Result:\n" + resMessage);
            System.out.println("Enter option:\n>>\t");
            String option = br.readLine();
            switch (option) {
                case "0":
                    exit = true;
                    resMessage = "Bye!";
                    break;
                case "1":
                    resMessage = viewDoctors();
                    break;
                case "2":
                    resMessage = ViewAppointments();
                    break;
                case "3":
                    resMessage = addDoctor();
                    break;
                case "4":
                    resMessage = removeDoctor();
                    break;
                case "5":
                    resMessage = updateDoctor();
                    break;
                case "6":
                    resMessage = addNewAppointment();
                    break;
                case "7":
                    resMessage = cancelAppointment();
                    break;
                case "8":
                    resMessage = updateAppointment();
                    break;
                default:
                    resMessage = "Invalid option!";
            }
        }
    }
}
