package domain;

import java.util.Objects;

public class DoctorAppointments implements Identifiable<Integer> {
    private Integer id;
    private Doctor appointedDoctor;
    private Patient patient;

    public DoctorAppointments(Integer id, Doctor reservedDoctor, Patient patient) {
        this.id = id;
        this.appointedDoctor = reservedDoctor;
        this.patient = patient;
    }

    @Override
    public Integer getId() {
        return this.id;
    }

    @Override
    public void setId(Integer id){
        this.id = id;
    }

    @Override
    public String toString() {
        return "DoctorReservation{" +
                "id: " + id +
                ", appinted doctor: " + appointedDoctor +
                ", patient: " + patient +
                '}';
    }

    @Override
    public int hashCode() {
        return id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || o.getClass() != this.getClass())
            return false;
        DoctorAppointments doctorReservation = (DoctorAppointments) o;
        return Objects.equals(doctorReservation, doctorReservation.id);
    }

    public Doctor getApointedDoctor() {
        return appointedDoctor;
    }

    public void setApointedDoctor(Doctor reservedDoctor) {
        this.appointedDoctor = reservedDoctor;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient){
        this.patient = patient;
    }
}
