package services;

import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.Properties;
import javax.security.auth.login.LoginException;
import java.io.FileInputStream;

import domain.Doctor;
import domain.DoctorAppointments;
import domain.Patient;
import repository.AppointmentsRepository;
import repository.DoctorRepository;
import repository.DoctorRepositoryBinaryFile;
import repository.DoctorRepositoryTextFile;
import repository.IRepository;
import repository.MemoryRepository;
import repository.AppointmentsRepositoryBinaryFile;
import repository.AppointmentsRepositoryTextFile;

public class Services {

    private IRepository<Integer, Doctor> freeDoctors;
    private IRepository<Integer, DoctorAppointments> appointments;

    public void initFiles() throws IOException {
        Properties properties = new Properties();
        properties.load(new FileInputStream("settings.properties"));

        String repositoryType = properties.getProperty("Repository");
        String appointmentsFileName = properties.getProperty("Appointments");
        String doctorsFileName = properties.getProperty("Doctors");

        if ("binary".equals(repositoryType)) {
            freeDoctors = new DoctorRepositoryBinaryFile<>(doctorsFileName);
            appointments = new AppointmentsRepositoryBinaryFile<>(appointmentsFileName);
        }
        else {
            freeDoctors = new DoctorRepositoryTextFile<>(doctorsFileName);
            appointments = new AppointmentsRepositoryTextFile<>(appointmentsFileName);
        }
    }


    //private DoctorRepository freeDoctors = new DoctorRepository();
    private int validDoctorId = 0;

    //private AppointmentsRepository appointments = new AppointmentsRepository();

    // private void initDoctors() {
    //     Doctor d1 = new Doctor(1, "John", "1234567890123", "address1", "specialization1");
    //     Doctor d2 = new Doctor(2, "Mary", "1234567890124", "address2", "specialization2");
    //     Doctor d3 = new Doctor(3, "James", "1234567890125", "address3", "specialization3");
    //     Doctor d4 = new Doctor(4, "Patricia", "1234567890126", "address4", "specialization4");
    //     Doctor d5 = new Doctor(5, "Robert", "1234567890127", "address5", "specialization5");
    //     Doctor d6 = new Doctor(6, "Jennifer", "1234567890128", "address6", "specialization6");
    //     Doctor d7 = new Doctor(7, "Michael", "1234567890129", "address7", "specialization7");
    //     Doctor d8 = new Doctor(8, "Linda", "1234567890130", "address8", "specialization8");
    //     Doctor d9 = new Doctor(9, "William", "1234567890131", "address9", "specialization9");
    //     Doctor d10 = new Doctor(10, "Elizabeth", "1234567890132", "address10", "specialization10");

    //     freeDoctors.add(d1);
    //     freeDoctors.add(d2);
    //     freeDoctors.add(d3);
    //     freeDoctors.add(d4);
    //     freeDoctors.add(d5);
    //     freeDoctors.add(d6);
    //     freeDoctors.add(d7);
    //     freeDoctors.add(d8);
    //     freeDoctors.add(d9);
    //     freeDoctors.add(d10);
    // }

    // private void initAppointments() {
    //     Patient p1 = new Patient(1, "Mathew", "1234567890123", "address1", "appointmentDate1", "specialization1");
    //     Patient p2 = new Patient(2, "David", "1234567890124", "address2", "appointmentDate2", "specialization2");
    //     Patient p3 = new Patient(3, "Julia", "1234567890125", "address3", "appointmentDate3", "specialization3");
    //     Patient p4 = new Patient(4, "Patrick", "1234567890126", "address4", "appointmentDate4", "specialization4");
    //     Patient p5 = new Patient(5, "Rafael", "1234567890127", "address5", "appointmentDate5", "specialization5");

    //     makeAppointment(1, p5);
    //     makeAppointment(2, p4);
    //     makeAppointment(3, p3);
    //     makeAppointment(4, p2);
    //     makeAppointment(5, p1);
    // }

    public void initRepositories() throws IOException {
        initFiles();
    }

    public Services() throws IOException{
        initRepositories();
    }

    public Iterable<DoctorAppointments> appointments() {
        return appointments.getAll();
    }

    public DoctorAppointments makeAppointment(int doctorId, Patient patient) throws NoSuchElementException, RuntimeException {
        if (appointments.findByID(doctorId) != null)
            throw new RuntimeException("Doctor already has an appointment!");
        Doctor appointedDoctor = removeFreeDoctor(doctorId);
        DoctorAppointments appointment = new DoctorAppointments(appointedDoctor.getId(), appointedDoctor, patient);
        appointments.add(appointment);
        return appointment;
    }

    public DoctorAppointments cancelAppointment(int appointmentId) throws NoSuchElementException {
        DoctorAppointments appointment = appointments.findByID(appointmentId);
        if (appointment == null)
            throw new RuntimeException("Appointment does not exist!");
        else {
            freeDoctors.add(appointment.getApointedDoctor());
            appointments.delete(appointmentId);
            return appointment;
        }
    }

    public DoctorAppointments getAppointment(int appointmentId) throws NoSuchElementException {
        DoctorAppointments appointment = appointments.findByID(appointmentId);
        if (appointment == null)
            throw new RuntimeException("Appointment does not exist!");
        else
            return appointment;
    }

    public int numberOfAppointments() {
        return appointments.size();
    }

    public Iterable<Doctor> freeDoctors() {
        return freeDoctors.getAll();
    }

    public Doctor addNewFreeDoctor(String name, String phone, String address, String specialization) {
        Doctor doctor = new Doctor(validDoctorId++, name, phone, address, specialization);
        freeDoctors.add(doctor);
        return doctor;
    }

    public Doctor removeFreeDoctor(int doctorId) throws NoSuchElementException{
        Doctor doctor = freeDoctors.findByID(doctorId);
        if (doctor == null)
            throw new RuntimeException("Doctor does not exist!");
        else
            return freeDoctors.delete(doctorId);
    }

    public Doctor getFreeDoctorById(int doctorId) throws NoSuchElementException{
        Doctor doctor = freeDoctors.findByID(doctorId);
        if (doctor == null)
            throw new RuntimeException("Doctor does not exist!");
        else
            return doctor;
    }

    public int numberOfFreeDoctors() {
        return freeDoctors.size();
    }
}
